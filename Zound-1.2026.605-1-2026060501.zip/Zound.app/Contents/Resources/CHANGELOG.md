# Changelog

## 1.2026.605-1 — 2026-06-05

- Hardened meeting recording processing so sped-up or pitch-shifted mixdowns are rejected before they can be saved as successful captures.
- Preserved the original recording when processed audio timing is invalid, making recovery possible without uploading a broken file.

## 1.2026.604-1 — 2026-06-04

- Fixed meeting recordings where system audio could be saved too short, sped up, and pitch-shifted.
- Added a finished-recording duration check so invalid captures are detected and preserved for recovery instead of being discarded.

## 1.2026.602-1 — 2026-06-02

- Fixed meeting recordings so quiet system-audio moments no longer trigger a System Audio Issue toast or discard the recording.
- Fixed recording uploads that could fail with a signed request body mismatch before transcription starts.
- Reduced unnecessary diagnostics from expected activation, microphone, and reauthorization states so real production issues are easier to spot.

## 1.2026.526-3 — 2026-05-26

- Fixed meeting recordings started with System Default microphone so Bluetooth headset inputs no longer cause pitched-up audio or missing microphone tracks.
- Added a Show in Finder button to Recording Drafts so saved audio is easier to locate.
- Improved live recording microphone warnings so capture problems appear as toasts without sending unnecessary error reports.

## 1.2026.526-2 — 2026-05-26

- Fixed system-audio recording warnings so they appear as toasts instead of taking over the menu bar.
- Fixed the Live Captions panel so it can be dragged to the top of the visible screen area.

## 1.2026.526-1 — 2026-05-26

- Reduced unnecessary error reports from expected microphone, activation, and system-audio states.
- Fixed recording summaries so empty transcripts no longer trigger a summary failure.
- Improved microphone cleanup to reduce the chance of Zound hanging while audio capture shuts down.

## 1.2026.525-4 — 2026-05-25

- Added a Recording Island setting so you can choose whether the recording status island stays on the left or right screen edge.
- Improved recording island dragging so it remembers vertical placement while staying pinned to the selected edge.
- Localized more toast notification text and refined notification icons for clearer status updates.

## 1.2026.525-3 — 2026-05-25

- Added a floating recording status island so recording, transcription, and system-audio states are easier to monitor while you work.
- Added in-app toast notifications for recording, import, transcription, captions, dictation, activation, permissions, export, and account events.
- Improved recording diagnostics and processed-audio validation so silent system audio, stalled capture, and invalid processed audio surface more clearly.

## 1.2026.525-2 — 2026-05-25

### Dictation Accuracy

- Improved dictation so mixed English, Chinese, names, and product terms keep more natural spacing.
- Zound now waits for a cleaner final result after you release the shortcut, reducing missing endings and odd spaces.
- Dictation follows your selected transcription languages more closely, especially when switching between languages.

### Reliability

- Fixed reactivation so a Mac that needs activation again can use a fresh invite code without getting stuck.
- Improved microphone handling when external devices are unplugged, quiet, or briefly stop sending audio.
- Reduced unnecessary alerts from recoverable dictation pauses.

### Dictionary

- Added a dedicated terms list for names, product names, acronyms, and phrases you want Zound to recognize.
- You can paste multiple terms at once, and Zound turns them into editable tags automatically.
- Dictionary settings now separate important terms from longer notes, making recognition easier to tune.

## 1.2026.525-1 — 2026-05-25

- Fixed reactivation so a Mac that is asked to activate again can use a fresh invite without hitting a temporary activation error.

## 1.2026.521-3 — 2026-05-21

- Added tag-style dictionary terms with paste parsing, so names, products, and domain phrases are easier to manage.
- Improved dictionary handling so important terms are prepared more reliably for transcription.
- Localized the new dictionary controls and kept background context separate from the term list.

## 1.2026.521-2 — 2026-05-21

- Fixed a microphone selection regression that could stop dictation and recording from starting after an unavailable external microphone was preserved in settings.

## 1.2026.521-1 — 2026-05-21

- Fixed hold-to-talk dictation so the final words are preserved when transcription is slow to finish.
- Improved selected-microphone recording so external microphones that are quiet or briefly silent still capture correctly instead of being treated as unavailable.
- Improved recovery when dictation is interrupted, so Zound can stop cleanly and be ready for the next attempt.
- Improved dictation reliability when speech recognition is temporarily unavailable.

## 1.2026.514-4 — 2026-05-14

- Fixed English dictation so split words like "email" and "deal" stay together.
- Improved the microphone check so the default microphone name is easier to understand.

## 1.2026.514-3 — 2026-05-14

- Fixed recording startup so microphone checks no longer interrupt an active recording.
- Improved audio capture so recordings handle device and timing hiccups more reliably.
- Improved dictation spacing so words and phrases stay separated naturally.
- Added clearer error reports so we can spot and fix Zound problems faster.
- Fixed a menu issue that could make Zound feel stuck or repeat an action.

## 1.2026.514-2 — 2026-05-14

- Renamed Library to Transcripts and made it the main place for completed recordings and archived live-caption sessions.
- Recording details now open in the transcript draft view, with export in the toolbar and editable recording titles.
- Dictation History is now Dictations across the app, with matching menu-bar grouping and cleaner toolbar actions.
- Fixed English dictation spacing so natural phrases like "right now", "I'm just", and "trying to" stay separated.
- Live-vs-final transcript comparisons now highlight changed words, making review differences easier to scan.

## 1.2026.514-1 — 2026-05-14

- Added a unified Transcripts window that brings completed recordings and archived live-caption sessions into a single home, with filters, search, and quick navigation between linked items.
- Added a live-vs-final transcript comparison view: when a caption session is captured during a recording, you can now see the live captions and the final transcript side by side once processing finishes. Open Linked Recording jumps straight to the parent from a caption.
- Added automatic silence trimming for finished recordings. Leading and trailing silence is removed during save (with a small safety pad). Skipped when savings would be negligible or the file is fully silent. Toggle this from General settings (on by default); dictation audio is untouched.
- Added activate and processing sound cues for dictation and recording so you get audible feedback when a session starts and when transcription finishes. Toggle from General settings (on by default).
- Live caption sessions are now automatically archived when you close the translator panel, so captions are no longer dropped on the floor when the panel is dismissed.
- Closing the live-captions panel now fully tears down the translator session — no more lingering processing in the background.
- Fixed phantom spaces inside English dictation transcripts so subword splits no longer land as gaps inside a single word.
- Refined the Dictations toolbar layout for clearer replay, copy, delete, and re-transcribe actions.

## 1.2026.513-12 — 2026-05-13

- Fixed Chinese and Japanese dictation spacing so words stay intact mid-sentence (for example, "星 期三" now stays as "星期三"). Korean, Latin, and digit boundaries are preserved.
- Dictation history, the transcript draft caption, and the Recent Recordings menu now show human-readable relative dates like "just now", "5m ago", or "2d ago". Hover any entry to see the full absolute timestamp.
- Empty dictations from very brief hotkey taps or silent moments are now silently dismissed for the first two in a row — no error pill, no history row. A third consecutive empty still surfaces the error so a genuinely broken setup announces itself.
- Improved the dictation island appearance on macOS 26 glass so its content tones follow the visible backdrop rather than only the system appearance, staying readable on both Light and Dark wallpapers.
- Localized the menu bar "Dictations…" item in Simplified Chinese.

## 1.2026.513-11 — 2026-05-13

- Improved dictation connection handling so older prepared sessions are refreshed before they can fail.
- Fixed the dictation island so it matches the system appearance on macOS 26 — no more dark capsule with light text in Light Mode.
- The error state now shows the actual failure message on hover, so you can see what went wrong without checking history.
- Failed dictations now save their captured audio to Dictations, so you can replay or re-transcribe them instead of losing the recording.
- Dictations is now fully localized in Simplified Chinese.

## 1.2026.513-10 — 2026-05-13

- Refined the Dictations toolbar with clearer actions for replay, copy, delete, and re-transcribe.
- Improved the dictation island error state with a clearer message and easier recovery.
- Made re-transcribing past dictations more reliable.
- Polished Simplified Chinese copy across dictation, history, and settings for consistent terminology.

## 1.2026.513-9 — 2026-05-13

- Added Dictations to review, replay, copy, delete, and re-transcribe past dictations, including failed or timed-out sessions.
- Added Dictations settings for saving audio and automatic cleanup.
- Improved long dictations so trailing speech is less likely to be cut off while finishing.
- Refined the dictation island with a clearer error state, a cleaner live waveform, and a smaller animated processing state.
- The Context Dictionary editor now grows as you add longer content.

## 1.2026.513-8 — 2026-05-13

- Fixed dictation finishing so the last words stay intact after you stop speaking.
- Refined the dictation pill hover controls so the cancel and confirm buttons sit evenly inside the capsule.

## 1.2026.513-7 — 2026-05-13

- Fixed hold-to-talk dictation so it returns final text promptly after you stop speaking.
- Added a safety path that can finish dictation from the latest recognized text when the final result is delayed.

## 1.2026.513-6 — 2026-05-13

- Added Import Audio so you can bring existing audio files into Zound and transcribe them like new recordings.
- Improved hold-to-talk dictation quality while keeping temporary dictation recordings cleaned up after completion.
- Reduced the dictation island hover timer size so the compact pill controls stay readable without crowding.

## 1.2026.513-5 — 2026-05-13

- Fixed dictation island colors so light mode uses a light capsule with dark controls, and dark mode uses a dark capsule with light controls.

## 1.2026.513-4 — 2026-05-13

- Fixed the dictation island so its content appears in the floating panel instead of creating an invisible blank panel.

## 1.2026.513-3 — 2026-05-13

- Fixed dictation shortcuts so Fn, modifier keys, and custom hotkeys reliably trigger after updates or permission resets.
- Dictation shortcuts now also work while Zound Settings is frontmost, without firing while recording a new custom hotkey.

## 1.2026.513-2 — 2026-05-13

- Fixed the dictation pill hover state so cancel and confirm controls no longer flicker under the pointer.
- Refined the dictation pill layout so the app icon and status icon sit at the outer edges while the hover timer stays centered.
- Redesigned Dictionary settings with a clearer editor, usage limit feedback, and a visible automatic-save state.

## 1.2026.513-1 — 2026-05-13

- Improved saved recording transcription quality for beta builds.
- Made recording and dictation language handling more consistent in beta builds.

## 1.2026.512-2 — 2026-05-12

- Fixed Activation Mode in Dictation settings so the selected mode stays saved instead of snapping back.
- Added Left Control + Space support through custom dictation hotkeys, with Delete clearing the current shortcut recording.
- Made the dictation island a compact pill with hover controls to cancel or confirm dictation and a running timer.
- Added a setting to keep the dictation pill fixed at the bottom center or show it near the active input box.
- Moved Dictionary into its own Settings tab right after General for faster access.

## 1.2026.512-1 — 2026-05-12

- Added customizable dictation hotkeys, including left-side modifier keys and custom key chords with live shortcut previews.
- Added a Clear action to the Customize Hotkey sheet so you can reset a custom shortcut without changing other dictation settings.
- Removed analytics tracking from Zound.
- Added the Zound Beta release channel for privately distributed beta builds and in-app beta updates.

## 1.2026.509-2 — 2026-05-09

- Fixed update windows so they come to the front when opened from the menu bar or Settings.
- Improved the installer so new installs include an Applications shortcut, preventing macOS download-location launches from blocking future auto-updates.

## 1.2026.509-1 — 2026-05-09

- Fixed microphone selection so recordings and hold-to-talk dictation use the input device you choose in Settings.

## 1.2026.430-2 — 2026-04-30

- Added an About section in Settings with the app icon, current version, update checks, and changelog access.
- Settings are now fully localized in Simplified Chinese, including Dictation keyboard shortcuts, activation modes, and Dictionary help text.
- Removed the floating Orb feature and its General Settings toggle, keeping Zound focused on the menu bar, Settings, and Voice Island surfaces.
- Improved Dictation recovery when connections drop or finishing takes longer than expected, so completed text is preserved more reliably.

## 1.2026.430-1 — 2026-04-30

- Refined the Voice Island into a smaller, cleaner Liquid Glass-style panel that stays focused on dictation progress without extra status text.
- Live dictation now shows in-progress recognized text while you keep holding Fn, instead of waiting until the session finishes.
- Final dictation text handles word boundaries more reliably, reducing stray text and missing spaces in inserted text.
- Settings now use a clearer sidebar layout with grouped rows, making Dictation, Dictionary, and General controls easier to scan.
- Added an Enable Dictation switch so dictation can be turned off without changing shortcut or language preferences.
- Expanded Activation Keys with right-side modifier keys and common modifier combinations, alongside Fn.
- Added Hold, Toggle, Hold or Toggle, and Double Tap activation modes, with more reliable behavior when modifier chords change or dictation is disabled mid-session.

## 1.2026.428-2 — 2026-04-28

- Made Fn dictation start faster by preparing dictation after launch and between sessions.
- Improved hold-to-talk dictation speed while keeping saved recording quality intact.
- Added a Dictation Health check in Dictation Settings to verify readiness and measure connection speed.

## 1.2026.428-1 — 2026-04-28

- Lowered Zound's minimum macOS requirement to macOS Sequoia 15.0 or later.

## 1.2026.427-4 — 2026-04-27

- Restored faster hold-to-talk dictation so spoken audio is processed immediately instead of waiting for an upload cycle.
- Removed connection status text from the voice island during dictation, keeping the active UI focused on the waveform and final inserted text.
- Shortened dictation finishing waits while keeping private connection details protected.

## 1.2026.427-3 — 2026-04-27

- Fixed dictation's no-audio error so it correctly points to microphone capture instead of meeting/system audio.

## 1.2026.427-2 — 2026-04-27

- Switched hold-to-talk dictation to a more reliable recognition path, keeping voice typing available.
- Dictation status and errors are now readable in the voice island instead of being cropped out.

## 1.2026.427-1 — 2026-04-27

- New hold-to-talk dictation: hold Fn to speak and Zound types finalized text into the app you were already using.
- Added a lightweight voice island that appears near the text cursor, falls back to bottom center when needed, and shows a responsive waveform while you talk.
- Added a new hold-to-talk dictation flow that keeps writing dictation separate from meeting recording and Live Captions.
- Added Keyboard Controls in Settings so you can choose Fn or another preset modifier shortcut for hold-to-talk recording.
- Added dictation setup guidance to onboarding, including microphone and accessibility permission checks without requiring System Audio permission.
- Dictation respects your transcription language hints and context dictionary for better names, products, jargon, and code-switching.
- Final audio and connection failures during dictation are now surfaced instead of silently clearing the session.

## 1.6.0 — 2026-04-27

- Recording details now have a built-in playback bar pinned to the bottom of the window, so you can listen to the audio while reading the transcript.
- The waveform is colored by speaker, giving you an at-a-glance map of who's talking when across the entire timeline.
- Click anywhere on the waveform to scrub, hover to preview the speaker and timestamp at that point, or tap any transcript turn to jump straight to it.
- The active speaker turn highlights as audio plays and gently scrolls into view, so you never lose your place.
- Transport controls include play/pause, ±10 second skip, and a 0.75×–2× speed menu, with Space, ←/→, and Shift+←/→ keyboard shortcuts.

## 1.5.0 — 2026-04-26

- Activation is now bound to your Mac — invite codes lock to the device that redeems them, so a leaked code can't be reused elsewhere.
- Live transcription and translation now use a more reliable, secure connection path for audio.
- Activation, transcription, and translation errors now appear in your selected app language with clearer descriptions when details are unavailable.

## 1.4.2 — 2026-04-23

- Fixed microphone capture so the recorded audio level is properly normalized, preventing quiet or unbalanced recordings.

## 1.4.1 — 2026-04-23

- Live Captions now show in-progress words in a lighter style, so you can follow along before each phrase is finalized.
- Selecting a suggested speaker name in a draft now assigns it immediately, so you do not need to click Done after choosing from the list.
- Completed the permission setup screen's Simplified Chinese localization so the onboarding flow stays fully translated.
- Refreshed the starting, idle, and recording menu bar icons with updated artwork.

## 1.4.0 — 2026-04-22

- Fixed the Context Dictionary so every change saves immediately and is still there after switching tabs or closing Settings.
- Refreshed Settings with a more native macOS preferences layout that sizes to its content and lines up controls more cleanly.

## 1.3.0 — 2026-04-21

- Personal context dictionary now starts blank, so you can add your own names, products, jargon, and acronyms instead of inheriting shared defaults.
- Speaker suggestions now start empty and learn from the names you actually assign.
- Added a Transcription Languages picker in Settings → General so you can choose which languages the transcriber should expect.
- Added a new "What's New" window after updates, plus a "View What's New…" shortcut in Settings.
- Refreshed the app icon and replaced the menu bar status glyphs with custom Zound artwork.
- Settings now opens more reliably from the menu bar and uses a more native macOS Tahoe layout.

## 1.2.2 — 2026-04-20

- Export transcripts as .txt or .md.
- Recording summaries generate a title and a short excerpt automatically.

## 1.2.1 — 2026-04-19

- Renamed the app to Zound. Fixes and polish across recording, transcription, and permissions.
